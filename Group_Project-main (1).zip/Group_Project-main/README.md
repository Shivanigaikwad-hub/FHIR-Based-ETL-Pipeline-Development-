# Group_Project

The website can be accessed through this link:

[Group Project Website](https://pages.github.iu.edu/shigaik/Group_Project/)
